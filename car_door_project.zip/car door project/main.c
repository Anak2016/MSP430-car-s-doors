#include <msp430.h>

#define LED1 BIT0
#define BUTTON1 BIT0

#define LED2 BIT1
#define BUTTON2 BIT1

#define LED3 BIT2
#define BUTTON3 BIT2

#define LED4 BIT3
#define BUTTON4 BIT3

#define LED5 BIT4
#define BUTTON5 BIT4


int main(void) {
    WDTCTL = WDTPW | WDTHOLD;								// Stop watchdog timer

	P1OUT= 0X00;
	P1DIR= LED1 | LED2 | LED3 | LED4 | LED5;				//BIT 0-4 of PORT1 are outputs.
	P2DIR= 0X00;											//PORT2 bits are inputs
	P2REN= BUTTON1 | BUTTON2 | BUTTON3 | BUTTON4 | BUTTON5; //  BIT0-4 of PORT 2 resistors are enabled.

	P2IE = BUTTON1 | BUTTON2 |BUTTON3 |BUTTON4| BUTTON5; 	//enable interupt from port P2 (bit 0-4)
	P2IES= BUTTON1 | BUTTON2 |BUTTON3 |BUTTON4| BUTTON5;	//interupt edge select from high to low
	P2IFG= 0X00; 											// clear the interupt flags

	 __enable_interrupt();
	
	for(;;){
		//infinite loop
	}
	return 0;
}

#pragma vector=PORT2_VECTOR
__interrupt void PORT2_ISR(void)
{
	//if button5 is pressed and led 1-4 are off then toggle led5
	 if((P2IN & BUTTON5 ) != BUTTON5 && (P1OUT & LED1) != LED1 && (P1OUT & LED2) != LED2 && (P1OUT & LED3) != LED3 && (P1OUT & LED4) != LED4)//car is unlocked
		{ P1OUT ^= LED5;__delay_cycles(200000);}

	 //if led5 is on then led1-4 will be toggle when buttons are pressed.
	if((P1OUT & LED5) != LED5)
	{
	    if((BUTTON1 & P2IN) != BUTTON1){P1OUT ^= LED1;__delay_cycles(200000);}
	    if((BUTTON2 & P2IN) != BUTTON2){P1OUT ^= LED2;__delay_cycles(200000);}
	    if((BUTTON3 & P2IN) != BUTTON3){P1OUT ^= LED3;__delay_cycles(200000);}
	    if((BUTTON4 & P2IN) != BUTTON4){P1OUT ^= LED4;__delay_cycles(200000);}
	}
}

