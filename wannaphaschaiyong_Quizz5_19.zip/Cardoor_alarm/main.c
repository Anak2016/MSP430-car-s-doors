#include <msp430.h> 

/*
 * main.c
 */

//int door1=0, door2=0, door3=0, door4=0, lock=0;

int main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
	P1OUT=0x10;
	P1DIR=0X1F;//(BIT 0-4)
	P2DIR=0X00;//(BIT 0-4)
	P2REN= 0x1F;
	
	/*
	 if(door button is pressed){POUT^= door LED;}

	 if(lock button is pressed and all LED button is off){POUT ^= doorLED;}
	 if(lock button is off){if(door button is pressed){POUT^=door LED;}
	 */
	for(;;){

	//part 1 code
/*
	if((BIT0 & P2IN) != BIT0){P1OUT ^= BIT0;__delay_cycles(100000); }
	if((BIT1 & P2IN) != BIT1){P1OUT ^= BIT1;__delay_cycles(100000); }
	if((BIT2 & P2IN) != BIT2){P1OUT ^= BIT2;__delay_cycles(100000); }
	if((BIT3 & P2IN) != BIT3){P1OUT ^= BIT3;__delay_cycles(100000); }
 //(P1OUT1 & BIT0) != BIT0
 // (P1OUT &(BIT0|BIT1|BIT2|BIT3)) !=(BIT0|BIT1|BIT2|BIT3)
	   */
	 if((P2IN & BIT4 ) != BIT4 && (P1OUT & BIT0) != BIT0 && (P1OUT & BIT1) != BIT1 && (P1OUT & BIT2) != BIT2 && (P1OUT & BIT3) != BIT3)//car is unlocked
	 { P1OUT ^= BIT4;__delay_cycles(200000);}
	 //if((P2IN & BIT4) == BIT4)
	 if((P1OUT & BIT4) != BIT4)//car is lock
	 {
    if((BIT0 & P2IN) != BIT0){P1OUT ^= BIT0;__delay_cycles(200000);}
    if((BIT1 & P2IN) != BIT1){P1OUT ^= BIT1;__delay_cycles(200000);}
    if((BIT2 & P2IN) != BIT2){P1OUT ^= BIT2;__delay_cycles(200000);}
    if((BIT3 & P2IN) != BIT3){P1OUT ^= BIT3;__delay_cycles(200000);}
	 }


	}
	return 0;
}
